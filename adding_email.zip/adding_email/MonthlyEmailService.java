package com.example.emailsender.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import jakarta.mail.internet.MimeMessage;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;

@Service
public class MonthlyEmailService {

    @Autowired
    private JavaMailSender mailSender;

    // 🕒 Run every month on the 27th at 9:00 AM
    @Scheduled(cron = "0 0 9 27 * *")
    public void sendMonthlyEmail() {
        System.out.println("⏰ Checking if today is the 27th for monthly email...");

        LocalDate today = LocalDate.now();
        if (today.getDayOfMonth() != 27) {
            System.out.println("Not the 27th, skipping email send.");
            return;
        }

        sendEmail("Automatic monthly email triggered by scheduler");
    }

    // Method reused by scheduler and REST endpoint
    public String sendEmail(String reason) {
        try {
            // Step 1: Read recipient email
            String email = Files.readString(Paths.get("email.txt")).trim();

            // Step 2: Determine file to attach
            String fileToSend = "monthly_report.txt";

            // Step 3: Create email
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true);

            helper.setTo(email);
            helper.setSubject("Monthly Report - " + LocalDate.now().getMonth() + " " + LocalDate.now().getYear());
            helper.setText("Attached is your monthly report. (" + reason + ")");

            FileSystemResource file = new FileSystemResource(new File(fileToSend));
            if (!file.exists()) {
                return "❌ Attachment file not found: " + fileToSend;
            }
            helper.addAttachment(file.getFilename(), file);

            // Step 4: Send it
            mailSender.send(message);
            String log = "✅ Email sent successfully to " + email;
            System.out.println(log);
            return log;

        } catch (Exception e) {
            e.printStackTrace();
            return "❌ Failed to send email: " + e.getMessage();
        }
    }
}
