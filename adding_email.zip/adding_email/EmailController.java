package com.example.emailsender.controller;

import com.example.emailsender.service.MonthlyEmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class EmailController {

    @Autowired
    private MonthlyEmailService emailService;

    // POST /api/send-now → triggers email immediately
    @PostMapping("/send-now")
    public String sendNow() {
        return emailService.sendEmail("Manual trigger via REST API");
    }
}
