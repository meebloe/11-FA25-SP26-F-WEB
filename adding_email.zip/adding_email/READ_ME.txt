READ ME:

GitHub is giving me nothing, probably a permission issue.
I can see files, but I can't push or pull them.

I used ChatGPT to make a program that emails from a Spring Boot html program once a month on the 27th.
It does want a Google App Password (not a Gmail Password) so that probably needs to be changed out if using WSU Microsoft.

The image shows the expected file structure.

This probably doesn't need to be in Sprint2, but the clients were asking about it, so I'm going to send it out by email.
Since I don't trust GitHub right now.

The EmailController.java is for manual testing. The email sender is timed to check the date at 9am, and send a text file if it's the 27th.
Updating that text file to be inventory data has to be done separately. And I don't have any of the java backend to do it with.
It can be changed to be a different time and the end of every month later. 

Replace the dummy email in email.txt with a real one. It should probably be encrypted in the real program.
The monthly report should be set up to be updated from the inventory before being emailed. May be changed from the .txt format later.
The email.txt and monthly_report.txt should be in the project root.

This curl command can be used to test: curl -X POST http://localhost:8080/api/send-now
